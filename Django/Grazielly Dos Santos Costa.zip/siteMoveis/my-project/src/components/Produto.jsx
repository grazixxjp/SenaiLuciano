import React from 'react';

const Produto = () => {
    return ( 
        <div className="Produto">
        <h1 class="text-black text-xl mt-6" >See our <corDifirent class="text-amber-300">Rug!</corDifirent></h1>
        <p class="text-xs text-gray-500">Made-to-measure special line sisal rug, produced in rustic vertical loom and manual sisal dyeing.</p>
        </div>
        )
  }

export default Produto;